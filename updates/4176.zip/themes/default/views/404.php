<br><br><br>
<section class="text-center">
 	<div class="intro_title error">
    	<h1 class="animated fadeInDown"><?php echo trans('0267');?></h1>
        <p class="animated fadeInDown"><?php echo trans('0268');?></p>
       <form action="<?php echo base_url(); ?>" method="post"><button type="submit" class="animated fadeInUp btn iosbtn"><?php echo trans('062');?></button></form>
	</div>
</section><!-- End hero -->
<br><br><br><br><br>
