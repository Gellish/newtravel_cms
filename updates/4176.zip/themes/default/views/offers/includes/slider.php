<div class="col-md-7 go-right">
<div class="fotorama bg-dark" data-allowfullscreen="true" data-nav="thumbs">
<?php foreach($offer->sliderImages as $img){ ?>
<img src="<?php echo $img['fullImage']; ?>" />
<?php } ?>
</div>
<div class="visible-xs visible-sm"><div style="margin-top:25px"></div></div>
</div>


