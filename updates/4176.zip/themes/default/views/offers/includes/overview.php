
<div id="DESCRIPTION" class="col-md-12">
<h4 class="go-right"><?php echo trans('046');?></h4>
<div class="clearfix"></div>
    <i class="tiltle-line go-right"></i>
<div class="clearfix"></div>
<p class="go-right RTL go-text-right"><?php echo $offer->desc; ?></p>
</div>
