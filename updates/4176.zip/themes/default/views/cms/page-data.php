<div class="container">
  <div class="col-md-12 pagecontainer2 offset-0">
    <div class="container">
      <h2 class="about_title"><?php echo @$page_contents[0]->content_page_title; ?></h2>
      <hr>
      <div class="panel-body go-right RTL about_rtl">
        <?php echo @$page_contents[0]->content_body; ?>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
</div>
<br><br><br>