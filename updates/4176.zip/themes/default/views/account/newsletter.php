<div class="panel-body">
<div class="pull-left">
<h4><?php echo trans('024');?></h4>
              <label class="switch-light switch-ios">
              <input type="checkbox" class="newsletter" value="<?php echo $profile[0]->accounts_email;?>" <?php if($is_subscribed){echo "checked";}?>>
              <span>
              <span><?php echo trans('0364');?></span>
              <span><?php echo trans('0363');?></span>
              </span>
              <a></a>
              </label>
            </div>
            </div>


